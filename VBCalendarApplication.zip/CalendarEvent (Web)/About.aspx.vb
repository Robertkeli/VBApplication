﻿
Partial Class About
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Request.QueryString("ID") IsNot Nothing Then
                Label1.Text = "THE EVENT ID: " + Request.QueryString("ID")
            End If
        End If
    End Sub
End Class
