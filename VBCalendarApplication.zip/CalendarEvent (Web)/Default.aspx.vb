﻿Imports System.Data
Partial Class _Default
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim dtEvents As New DataTable()
            dtEvents.Columns.Add(New DataColumn("ID", GetType(System.Int32)))
            dtEvents.Columns.Add(New DataColumn("EventDate", GetType(System.DateTime)))
            dtEvents.Columns.Add(New DataColumn("EventTitle"))
            dtEvents.Columns.Add(New DataColumn("EventDescription"))

            dtEvents.Rows.Add(1, DateTime.Now.AddDays(10), "Lunch Party", "Address: Sarova Hotel, 10 New CBD, Nairobi")
            dtEvents.Rows.Add(2, DateTime.Now.AddDays(7), "Dance Party", "Address: Sand Beach, 20 Pwani, Mombasa")
            dtEvents.Rows.Add(3, DateTime.Now.AddDays(2), "Dinner Party", "Address: Kempinski, 12 Westlands, Nairobi")

            ViewState("dtEvents") = dtEvents
        End If
    End Sub

    Protected Sub Calendar1_DayRender(sender As Object, e As DayRenderEventArgs)
        If e.Day.IsToday Then
            e.Cell.BorderColor = System.Drawing.Color.Silver
            e.Cell.BackColor = System.Drawing.Color.Bisque
            e.Cell.BorderStyle = BorderStyle.Solid
            e.Cell.BorderWidth = 2
        End If

        If ViewState("dtEvents") IsNot Nothing Then
            Dim dtEvents As DataTable = DirectCast(ViewState("dtEvents"), DataTable)
            For Each oItem As DataRow In dtEvents.Rows
                If Convert.ToDateTime(oItem("EventDate")).ToString("dd-MM-yyyy") = e.Day.[Date].ToString("dd-MM-yyyy") Then
                    Dim ltrl As New Literal()
                    ltrl.Text = "<BR />"
                    e.Cell.Controls.Add(ltrl)

                    e.Cell.BorderColor = System.Drawing.Color.Aqua
                    e.Cell.BackColor = System.Drawing.Color.Bisque
                    e.Cell.BorderStyle = BorderStyle.Solid
                    e.Cell.BorderWidth = 2

                    Dim b As New Label()
                    b.Font.Size = 8
                    b.Font.Bold = True
                    b.ForeColor = System.Drawing.ColorTranslator.FromHtml("#336699")
                    b.Text = oItem("EventTitle").ToString()
                    e.Cell.Controls.Add(b)

                    Dim ltrl2 As New Literal()
                    ltrl2.Text = "<BR /><a style='font-size:0.9em' href='About.aspx?ID=" & oItem("ID").ToString() & "'>View Address</a>"
                    e.Cell.Controls.Add(ltrl2)
                End If
            Next
        End If
    End Sub

    Protected Sub cmdCreate_Click(sender As Object, e As EventArgs)
        If ViewState("dtEvents") IsNot Nothing Then
            Dim dtEvents As DataTable = DirectCast(ViewState("dtEvents"), DataTable)
            dtEvents.Rows.Add(Convert.ToInt32(txtEventID.Text), Convert.ToDateTime(txtDate.Text), txtEvent.Text, txtEventDescription.Text)
            ViewState("dtEvents") = dtEvents
        End If
    End Sub
    Protected Sub cmdEdit_Click(sender As Object, e As EventArgs)

        Console.WriteLine("You don't have any event")

    End Sub

    Protected Sub cmdDelete_Click(sender As Object, e As EventArgs)

        Console.WriteLine("You have deleted the event")

    End Sub

End Class
